## E_MISSING_PARAMETER

Thrown when a required parameter is missing on any static or instance methods.

Error object:

| Attribute | Value |
| --- | --- |
| code | `E_MISSING_PARAMETER` |
| name | Name of the missing parameter |
