## E_DEFAULT_LOCALE_NOT_DEFINED

Thrown when any static method, eg. `Globalize.formatNumber()` is used prior to
setting the Global locale with `Globalize.locale( <locale> )`.

Error object:

| Attribute | Value |
| --- | --- |
| code | `E_DEFAULT_LOCALE_NOT_DEFINED` |
